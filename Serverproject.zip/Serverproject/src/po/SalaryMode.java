package po;

public enum SalaryMode {
	chargebytimes,monthly,deduct
}
