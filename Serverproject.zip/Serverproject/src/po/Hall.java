package po;

public enum Hall {
	Nanjing,Nanjing1,Nanjing2,Shanghai,
}
