package po;

public enum City {
	Beijing,Shanghai,Guangzhou,Nanjing
}
