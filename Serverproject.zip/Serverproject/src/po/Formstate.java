package po;

public enum Formstate {
	waiting,pass,fail
}
