package po;

public enum Arrivalstate {
	broken,lost,intact
}
