package po;

public enum Organization {
	hall,transfercenter
}
