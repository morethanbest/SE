package po;

public enum Job {
	Courier,hallsalesman,transfercenter,drivers
}
