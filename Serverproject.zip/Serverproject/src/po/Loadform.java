package po;

public enum Loadform {
	plane,train,truck
}
