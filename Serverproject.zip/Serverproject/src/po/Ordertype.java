package po;

public enum Ordertype {
	economical,normal,fast
}
